package main.com;

import org.openjdk.jmh.Main;

public class Start {
    public static void main(String[] args) throws Exception {
        Main.main(args); // Запуск бенчмарков через JMH
    }
}
