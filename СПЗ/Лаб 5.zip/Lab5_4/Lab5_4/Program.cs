﻿using System;
using System.Diagnostics;
using System.IO.Pipes;
using System.Threading;

class Program
{
    static void Main(string[] args)
    {
        Console.InputEncoding = System.Text.Encoding.UTF8;
        using (AnonymousPipeServerStream pipeServer = new AnonymousPipeServerStream(PipeDirection.Out, HandleInheritability.Inheritable))
        {
            string clientHandle = pipeServer.GetClientHandleAsString();
            Console.WriteLine("Server pipe handle: " + clientHandle);

            // Отримання повного шляху до клієнта
            string clientPath = Path.Combine(Directory.GetCurrentDirectory(), "Lab5_4-1.exe");
            Console.WriteLine("Client path: " + clientPath);

            // Перевірка існування файлу
            if (!File.Exists(clientPath))
            {
                Console.WriteLine("Client executable not found at: " + clientPath);
                return;
            }

            // Запуск клієнта з передачею дескриптора каналу через стандартний вхід
            Process clientProcess = new Process();
            clientProcess.StartInfo.FileName = clientPath;
            clientProcess.StartInfo.UseShellExecute = false;
            clientProcess.StartInfo.RedirectStandardInput = true;

            try
            {
                clientProcess.Start();
                clientProcess.StandardInput.WriteLine(clientHandle);
                clientProcess.StandardInput.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Failed to start client process: " + ex.Message);
                return;
            }

            // Надсилання даних клієнту
            using (StreamWriter writer = new StreamWriter(pipeServer))
            {
                writer.AutoFlush = true;
                string message = "Hello from Server!";
                int count = 5;

                writer.WriteLine(message);
                writer.WriteLine(count);
            }

            clientProcess.WaitForExit();
            pipeServer.DisposeLocalCopyOfClientHandle();
        }
    }
}
