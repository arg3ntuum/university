﻿// Клієнтський процес (Client)

using System;
using System.Drawing;
using System.IO;
using System.IO.Pipes;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Lab5_t4_v5_2c
{
    public partial class Form1 : Form
    {
        private NamedPipeClientStream pipeClient;
        private StreamReader reader;
        private Thread clientThread;

        public Form1()
        {
            InitializeComponent();
            StartClient();
        }

        private void StartClient()
        {
            clientThread = new Thread(ClientThreadFunc);
            clientThread.IsBackground = true;
            clientThread.Start();
        }

        private void ClientThreadFunc()
        {
            try
            {
                using (pipeClient = new NamedPipeClientStream(".", "MyPipe", PipeDirection.In))
                {
                    pipeClient.Connect();

                    using (reader = new StreamReader(pipeClient))
                    {
                        while (true)
                        {
                            string colorCode = reader.ReadLine();
                            if (colorCode != null)
                            {
                                string[] rgb = colorCode.Split(',');
                                int r = int.Parse(rgb[0]);
                                int g = int.Parse(rgb[1]);
                                int b = int.Parse(rgb[2]);

                                
                                UpdateInterface(r, g, b);
                            }
                        }
                    }
                }
            }
            catch (IOException ex)
            {
                MessageBox.Show("Сервер відключений.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка клієнта: " + ex.Message);
            }
        }

        private void UpdateInterface(int r, int g, int b)
        {
            if (this.InvokeRequired)
            {
                this.Invoke((MethodInvoker)delegate {
                    this.BackColor = Color.FromArgb(r, g, b);
                    this.label1.Text = $"RGB: {r}, {g}, {b}";
                });
            }
            else
            {
                this.BackColor = Color.FromArgb(r, g, b);
                this.label1.Text = $"RGB: {r}, {g}, {b}";
            }
        }
    }
}
