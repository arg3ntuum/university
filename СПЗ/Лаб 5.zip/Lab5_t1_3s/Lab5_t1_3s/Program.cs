﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO.Pipes;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Lab5_t1_3s
{
    internal class Server
    {
        const string EXE_PATH = @"C:\Users\User\source\repos\Lab5_t1_3c\Lab5_t1_3c\bin\Debug\Lab5_t1_3c.exe";

        Thread[] serverThreads;

        int numClients;

        byte[] byteMessage;

        public Server(int numClients)

        {

            this.numClients = numClients;

            serverThreads = new Thread[numClients];

        }

        public void Start(string message)

        {

            byteMessage = Encoding.ASCII.GetBytes(message);

            for (int i = 0; i < numClients; i++)

            {

                serverThreads[i] = new Thread(ServerThread);

                serverThreads[i].Start();

            }

        }

        private void ServerThread()

        {

            try

            {

                int threadID = Thread.CurrentThread.ManagedThreadId;

                NamedPipeServerStream serverPipe = new NamedPipeServerStream("pipe" + threadID, PipeDirection.InOut, 1);

                //client creating

                ProcessStartInfo info = new ProcessStartInfo

                {

                    FileName = EXE_PATH,

                    Arguments = threadID.ToString()

                };

                Process client = Process.Start(info);

                Console.WriteLine("[{0}] Waiting for client...", threadID);

                serverPipe.WaitForConnection();

                //sending

                serverPipe.Write(byteMessage, 0, byteMessage.Length);

                // чекаємо поки клієнт отримає повідомлення

                serverPipe.WaitForPipeDrain();

                Console.WriteLine("[{0}] Client has received the message", threadID);

                //receive

                byte[] reqBytes = new byte[100];

                serverPipe.Read(reqBytes, 0, 100);

                Console.WriteLine("[{0}] Got request: {1}", threadID, Encoding.ASCII.GetString(reqBytes));

                client.WaitForExit();

                Console.WriteLine("[{0}] Client has exited", threadID);

            }

            catch (Exception ex)

            {

                Console.WriteLine("Error: " + ex.Message);

                return;

            }

        }

    }

    class Program

    {

        static void Main(string[] args)

        {

            Console.WriteLine("Process Server.");

            Console.Write("Count of processes: ");

            int count = Convert.ToInt32(Console.ReadLine());

            //create server

            Server server = new Server(count);

            Console.Write("Enter message: ");

            //starting server

            server.Start(Console.ReadLine());

            Console.ReadKey();

        }
    }
}
