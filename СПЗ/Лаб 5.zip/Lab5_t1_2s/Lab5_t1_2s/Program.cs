﻿using System;
using System.Collections.Generic;
using System.IO.Pipes;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5_t1_2s
{
    internal class Program
    {
        static void Main(string[] args)

        {

            Console.WriteLine("Process Server.");

            NamedPipeServerStream serverPipe = new NamedPipeServerStream("myPipe", PipeDirection.InOut, 1);

            Console.WriteLine("Waiting for client...");

            serverPipe.WaitForConnection();

            Console.WriteLine("Client has connected...");

            Console.WriteLine("Press any key to continue");

            Console.ReadKey();

            try

            {

                //send

                byte sendData = 48;

                serverPipe.WriteByte(sendData);

                Console.WriteLine("Sended: " + sendData);

                //receive

                int dataReceive = serverPipe.ReadByte();

                Console.WriteLine("Received: " + dataReceive);

                serverPipe.Close();

            }

            catch (IOException ex)

            {

                Console.WriteLine("Error: " + ex.Message);

            }

            Console.ReadKey();

        }
    }
}
