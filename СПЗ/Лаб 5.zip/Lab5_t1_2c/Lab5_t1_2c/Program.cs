﻿using System;
using System.Collections.Generic;
using System.IO.Pipes;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace Lab5_t1_2c
{
    internal class Program
    {
        static void Main(string[] args)

        {

            Console.WriteLine("Process client.");

            //connect

            NamedPipeClientStream pipe = new NamedPipeClientStream(".", "myPipe",

            PipeDirection.InOut, PipeOptions.None, TokenImpersonationLevel.None);

            pipe.Connect();

            Console.WriteLine("Connected with server");

            //read data

            int dataReceive = pipe.ReadByte();

            Console.WriteLine("Client receive: " + dataReceive.ToString());

            //write data

            byte dataSend = 24;

            pipe.WriteByte(dataSend);

            Console.WriteLine("Client send: " + dataSend.ToString());

            //close pipe

            pipe.Close();

            Console.ReadKey();

        }
    }
}
