﻿using System;
using System.Collections.Generic;
using System.IO.Pipes;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5_t1_1c
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("PROCESS CLIENT.");
            Random rand = new Random();
            if (args.Length > 0)
            {
                using (PipeStream pipeClient = new AnonymousPipeClientStream(PipeDirection.Out, args[0]))
                {
                    using (StreamWriter sw = new StreamWriter(pipeClient))
                    {
                        sw.AutoFlush = true;
                        // Send a 'sync message' and wait for client to receive it.
                        sw.WriteLine("SYNC");
                        pipeClient.WaitForPipeDrain();
                        do
                        {
                            int num = rand.Next(0, 100);
                            sw.WriteLine(num);
                            Console.WriteLine("[CLIENT] Sended: " + num);
                            Console.Write("[CLIENT] Enter 'q' to exit or any key to continue: ");
                        }
                        while (Console.ReadLine() != "q");
                    }
                }
            }
        }
    }
}
