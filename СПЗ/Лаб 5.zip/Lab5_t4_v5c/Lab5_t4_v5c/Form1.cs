﻿using System;
using System.IO.Pipes;
using System.Text;
using System.Windows.Forms;

namespace Lab5_t4_v5c
{
    public partial class Form1 : Form
    {
        private readonly NamedPipeClientStream clientPipe = new NamedPipeClientStream(".", "ColorPipe", PipeDirection.In);

        public Form1()
        {
            InitializeComponent();
            InitializeNamedPipe();
        }

        private void InitializeNamedPipe()
        {
            try
            {
                clientPipe.Connect();
                WaitForData();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка підключення до іменованого каналу: {ex.Message}");
            }
        }

        private void WaitForData()
        {
            byte[] buffer = new byte[256];
            clientPipe.Read(buffer, 0, buffer.Length);
            string colorCode = Encoding.ASCII.GetString(buffer);
            string[] colorValues = colorCode.Split(',');

            this.Invoke((MethodInvoker)delegate
            {
                this.BackColor = System.Drawing.Color.FromArgb(
                    int.Parse(colorValues[0]),
                    int.Parse(colorValues[1]),
                    int.Parse(colorValues[2]));
                labelColorCode.Text = $"RGB: {colorValues[0]}, {colorValues[1]}, {colorValues[2]}";
            });

            clientPipe.Close();
            InitializeNamedPipe();
        }
    }
}
