﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO.Pipes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5_t2_3c
{
    public partial class Form1 : Form
    {
        private readonly NamedPipeClientStream clientPipe;
        private readonly int clientID;
        private readonly RichTextBox richTextBox;

        public Form1(string serverID, RichTextBox richTextBox)
        {
            clientID = Process.GetCurrentProcess().Id;
            clientPipe = new NamedPipeClientStream(".", "pipe" + serverID,
                PipeDirection.InOut, PipeOptions.None);
            this.richTextBox = richTextBox;
        }

        public void Start()
        {
            try
            {
                // Receive
                clientPipe.Connect();
                byte[] inBytes = new byte[100];
                clientPipe.Read(inBytes, 0, 100);
                string inStr = Encoding.ASCII.GetString(inBytes);
                AppendText("Received from server: " + inStr);

                // Send
                AppendText("Sending message to server...");
                byte[] outBytes = Encoding.ASCII.GetBytes("Hello, server! I'm your client #" + clientID);
                clientPipe.Write(outBytes, 0, outBytes.Length);

                // Wait for server to receive the message
                clientPipe.WaitForPipeDrain();
                AppendText("The message has been received by server");
            }
            catch (Exception ex)
            {
                AppendText("Error: " + ex.Message);
            }
        }

        private void AppendText(string text)
        {
            richTextBox.Invoke((MethodInvoker)delegate {
                richTextBox.AppendText(text + "\n");
            });
        }
    }
}
