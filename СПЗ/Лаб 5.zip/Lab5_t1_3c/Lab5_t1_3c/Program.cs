﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO.Pipes;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace Lab5_t1_3c
{
    public class Client
    {
        NamedPipeClientStream clientPipe;
        int clientID;
        public Client(string serverID)
        {
            clientID = Process.GetCurrentProcess().Id;
            clientPipe = new NamedPipeClientStream(".", "pipe" + serverID,
            PipeDirection.InOut, PipeOptions.None, TokenImpersonationLevel.None);
        }

        public void Start()
        {
            try
            {
                //receive
                clientPipe.Connect();
                byte[] inBytes = new byte[100];
                clientPipe.Read(inBytes, 0, 100);
                string inStr = Encoding.ASCII.GetString(inBytes);
                Console.WriteLine("\t Received from server: {0}", inStr);
                //send
                Console.WriteLine("\t Sending message to server...");
                byte[] outBytes = new byte[100];
                outBytes = Encoding.ASCII.GetBytes("\t Hello, server! I'm your client #" + clientID);
                clientPipe.Write(outBytes, 0, outBytes.Length);
                //чекаємо поки сервер отримає повідомлення
                clientPipe.WaitForPipeDrain();
                Console.WriteLine("\t The message has been received by server");
            }
            catch (Exception ex)
            {
                Console.WriteLine("\t Error: " + ex.Message);
                return;
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\t Process client.");
            Client client = new Client(args[0]);
            client.Start();
            Console.ReadKey();
        }
    }
}
