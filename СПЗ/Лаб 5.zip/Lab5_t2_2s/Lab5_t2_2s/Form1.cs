﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Pipes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5_t2_2s
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Text = "Server";
        }



        private void button1_Click(object sender, EventArgs e)
        {
            using (NamedPipeServerStream serverPipe = new NamedPipeServerStream("myPipe", PipeDirection.InOut, 1))
            {
                MessageBox.Show("Waiting for client...");
                serverPipe.WaitForConnection();
                MessageBox.Show("Client has connected...");
                byte sendData = 48;
                serverPipe.WriteByte(sendData);
                MessageBox.Show("Server sent: " + sendData.ToString());
                int dataReceive = serverPipe.ReadByte();
                MessageBox.Show("Server received: " + dataReceive);
            }
        }
    }
}
