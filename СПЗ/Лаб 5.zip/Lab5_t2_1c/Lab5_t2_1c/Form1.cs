﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Pipes;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5_t2_1c
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            Console.WriteLine("PROCESS CLIENT.");
            Random rand = new Random();

            string[] args = Environment.GetCommandLineArgs();

            if (args.Length > 1)
            {
                using (PipeStream pipeClient = new AnonymousPipeClientStream(PipeDirection.Out, args[1]))
                {
                    using (StreamWriter sw = new StreamWriter(pipeClient))
                    {
                        sw.AutoFlush = true;
                        // Send a 'sync message' and wait for client to receive it.
                        sw.WriteLine("SYNC");
                        pipeClient.WaitForPipeDrain();
                        do
                        {
                            int num = rand.Next(0, 100);
                            sw.WriteLine(num);
                            richTextBox1.AppendText("[CLIENT] Sent: " + num + "\n");
                            richTextBox1.AppendText("[CLIENT] Enter 'q' to exit or any key to continue: ");
                        }
                        while (Console.ReadLine() != "q");
                    }
                }
            }
        }
    }
}
