﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO.Pipes;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5_t2_3s
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            richTextBox.Clear();
            int count = Convert.ToInt32(txtCount.Text);
            string message = txtMessage.Text;

            Server server = new Server(count, message, richTextBox);
            server.Start();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
    internal class Server
    {
        private const string EXE_PATH = @"C:\Users\User\source\repos\Lab5_t1_3c\Lab5_t1_3c\bin\Debug\Lab5_t1_3c.exe";
        private readonly int numClients;
        private readonly string message;
        private readonly RichTextBox richTextBox;

        public Server(int numClients, string message, RichTextBox richTextBox)
        {
            this.numClients = numClients;
            this.message = message;
            this.richTextBox = richTextBox;
        }

        public void Start()
        {
            byte[] byteMessage = Encoding.ASCII.GetBytes(message);

            for (int i = 0; i < numClients; i++)
            {
                Thread serverThread = new Thread(ServerThread);
                serverThread.Start(byteMessage);
            }
        }

        private void ServerThread(object byteMessage)
        {
            try
            {
                int threadID = Thread.CurrentThread.ManagedThreadId;
                NamedPipeServerStream serverPipe = new NamedPipeServerStream("pipe" + threadID, PipeDirection.InOut, 1);

                // Client creation
                ProcessStartInfo info = new ProcessStartInfo
                {
                    FileName = EXE_PATH,
                    Arguments = threadID.ToString()
                };
                Process client = Process.Start(info);
                AppendText("[" + threadID + "] Waiting for client...");

                serverPipe.WaitForConnection();

                // Sending
                serverPipe.Write((byte[])byteMessage, 0, ((byte[])byteMessage).Length);
                serverPipe.WaitForPipeDrain();
                AppendText("[" + threadID + "] Client has received the message");

                // Receive
                byte[] reqBytes = new byte[100];
                serverPipe.Read(reqBytes, 0, 100);
                AppendText("[" + threadID + "] Got request: " + Encoding.ASCII.GetString(reqBytes));

                client.WaitForExit();
                AppendText("[" + threadID + "] Client has exited");
            }
            catch (Exception ex)
            {
                AppendText("Error: " + ex.Message);
            }
        }

        private void AppendText(string text)
        {
            richTextBox.Invoke((MethodInvoker)delegate {
                richTextBox.AppendText(text + "\n");
            });
        }
    }
}
