﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Pipes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5_t2_2c
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Text = "Client";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (NamedPipeClientStream pipe = new NamedPipeClientStream(".", "myPipe", PipeDirection.InOut))
            {
                pipe.Connect();
                int dataReceive = pipe.ReadByte();
                MessageBox.Show("Client received: " + dataReceive.ToString());
                byte dataSend = 24;
                pipe.WriteByte(dataSend);
                MessageBox.Show("Client sent: " + dataSend.ToString());
            }
        }
    }
}
