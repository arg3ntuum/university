﻿using System;
using System.IO.Pipes;

class Program
{
    static void Main()
    {
        // Отримання інформації про ідентифікатор каналу від сервера через стандартний вхід
        string pipeHandle = Console.ReadLine();

        // Підключення до анонімного каналу
        using (AnonymousPipeClientStream pipeClient = new AnonymousPipeClientStream(PipeDirection.In, pipeHandle))
        {
            // Створення читача для отримання даних від сервера
            using (StreamReader sr = new StreamReader(pipeClient))
            {
                // Отримання рядка та числа від сервера
                string lineFromServer = sr.ReadLine();
                int count = int.Parse(sr.ReadLine());

                // Виведення рядка вказану кількість разів
                for (int i = 0; i < count; i++)
                {
                    Console.WriteLine(lineFromServer);
                }
            }
        }

        Console.WriteLine("Клієнт: Закриття з'єднання з анонімним каналом.");
    }
}
