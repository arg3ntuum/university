﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO.Pipes;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5_t1_1s
{
    internal class Program
    {


        static Process client;

        const string EXE_PATH = @"C:\Users\User\source\repos\Lab5_t1_1c\Lab5_t1_1c\bin\Debug\Lab5_t1_1c.exe";

        static void Main(string[] args)

        {

            Console.WriteLine("\tPROCESS SERVER.");

            using (AnonymousPipeServerStream pipeServer = new AnonymousPipeServerStream(PipeDirection.In,

            HandleInheritability.Inheritable))

            {

                StartClient(pipeServer.GetClientHandleAsString());

                pipeServer.DisposeLocalCopyOfClientHandle();

                using (StreamReader sr = new StreamReader(pipeServer))

                {

                    string temp;

                    // Wait for 'sync message' from the client.

                    do

                    {

                        Console.WriteLine("\t[SERVER] Wait for sync...");

                        temp = sr.ReadLine();

                        if (temp == null)

                            break;

                    }

                    while (!temp.StartsWith("\tSYNC"));

                    Console.WriteLine("\t[SERVER] Client has connected");

                    do

                    {

                        temp = sr.ReadLine();

                        Console.WriteLine(string.IsNullOrEmpty(temp) ? "\t[SERVER] No response from client" :

                        "\t[SERVER] Received: " + temp);

                    }

                    while (!client.HasExited);

                }

                client.Close();

                Console.WriteLine("\t[SERVER] Client quit. Server terminating.");

                Console.ReadKey();

            }

        }

        static void StartClient(string clientHandle)

        {

            ProcessStartInfo info = new ProcessStartInfo(EXE_PATH);

            info.Arguments = clientHandle;

            info.UseShellExecute = false;

            client = Process.Start(info);

        }

    }
}
