﻿// Серверний процес (Server)
using System;
using System.Drawing;
using System.IO.Pipes;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5_t4_v5s
{
    public partial class Form1 : Form
    {
        private NamedPipeServerStream pipeServer;
        private Thread serverThread;
        private Random random;

        public Form1()
        {
            InitializeComponent();
            random = new Random();
            StartServer();
        }

        private void StartServer()
        {
            serverThread = new Thread(ServerThreadFunc);
            serverThread.IsBackground = true;
            serverThread.Start();
        }

        private void ServerThreadFunc()
        {
            try
            {
                pipeServer = new NamedPipeServerStream("MyPipe", PipeDirection.Out);
                pipeServer.WaitForConnection();

                while (true)
                {
                    
                    Color randomColor = Color.FromArgb(random.Next(256), random.Next(256), random.Next(256));

                    
                    UpdateFormColor(randomColor);

                    
                    string colorCode = $"{randomColor.R},{randomColor.G},{randomColor.B},";
                    byte[] buffer = Encoding.ASCII.GetBytes(colorCode);
                    pipeServer.Write(buffer, 0, buffer.Length);

                    Thread.Sleep(1000); 
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка сервера: " + ex.Message);
            }
            finally
            {
                pipeServer?.Close();
            }
        }

        private void UpdateFormColor(Color color)
        {
            if (this.InvokeRequired)
            {
                this.Invoke((MethodInvoker)delegate {
                    this.BackColor = color;
                });
            }
            else
            {
                this.BackColor = color;
            }
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
