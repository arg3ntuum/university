﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO.Pipes;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5_t2_1s
{
    public partial class Form1 : Form
    {
        private Process client;
        private const string EXE_PATH = @"C:\Users\User\source\repos\Lab5_t2_1c\Lab5_t2_1c\bin\Debug\Lab5_t2_1c.exe";

        public Form1()
        {
            InitializeComponent();
        }

        private void StartClient(string clientHandle)
        {
            ProcessStartInfo info = new ProcessStartInfo(EXE_PATH);
            info.Arguments = clientHandle;
            info.UseShellExecute = false;
            client = Process.Start(info);
        }

        private void ServerForm_Load(object sender, EventArgs e)
        {
            using (AnonymousPipeServerStream pipeServer = new AnonymousPipeServerStream(PipeDirection.In, HandleInheritability.Inheritable))
            {
                StartClient(pipeServer.GetClientHandleAsString());
                pipeServer.DisposeLocalCopyOfClientHandle();

                using (StreamReader sr = new StreamReader(pipeServer))
                {
                    string temp;

                    // Wait for 'sync message' from the client.
                    do
                    {
                        richTextBox1.AppendText("[SERVER] Wait for sync...\n");
                        temp = sr.ReadLine();
                        if (temp == null)
                            break;
                    }
                    while (!temp.StartsWith("SYNC"));

                    richTextBox1.AppendText("[SERVER] Client has connected\n");

                    do
                    {
                        temp = sr.ReadLine();
                        richTextBox1.AppendText(string.IsNullOrEmpty(temp) ? "[SERVER] No response from client\n" : "[SERVER] Received: " + temp + "\n");
                    }
                    while (!client.HasExited);
                }
                client.Close();
                richTextBox1.AppendText("[SERVER] Client quit. Server terminating.\n");
            }
        }
    }
}
